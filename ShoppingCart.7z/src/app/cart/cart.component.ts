import { Component, OnInit } from '@angular/core';
import { Product} from '../product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartProducts: Product[];
  bill:number= 0;
  constructor(private router : Router) { }
  flag:boolean=false;
  quantity:number=0;
  ngOnInit() {
    this.addToCart();
    
  }

  addToCart(){
      let data=localStorage.getItem('cart');
    if(data !== null){
      this.cartProducts = JSON.parse(data);
      this.flag=true;
    } else {
      this.cartProducts = [];
    }
    let cartData = localStorage.getItem('cart');
    this.cartProducts = JSON.parse(cartData);
    this.calculateBill();
    console.log(this.cartProducts);
  }

  getCartProducts(): Product[]{
    return this.cartProducts;
  }

  calculateBill():void{
      for(let c of this.cartProducts){
        this.bill += c.productPrice;
        this.quantity++; 
      }
  }
  clearCart():void{
    localStorage.clear();
    this.bill=0;
    this.quantity=0;
    this.flag=false;
    this.addToCart();

  }
  checkout():void{
    alert("Your order is confirmed");
    this.clearCart();    
  }

}
