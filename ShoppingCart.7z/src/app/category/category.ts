export interface IProduct {
    // categoryId: number;
    productCategory: string;
    imageUrl: string;
}