import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product';
import {CartComponent} from '../cart/cart.component';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ProductListComponent implements OnInit {
  products: Product[];
  selectedProduct: Product;
  cartProducts:any;
  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.getProducts();
    console.log(this.products);
  }
  onSelect(productx: Product): void {
    this.selectedProduct = productx; //alert(this.selectedProduct.productName);

      let product = this.selectedProduct;
      let cartData = [];  
      let data = localStorage.getItem('cart');
      if(data !== null){
        cartData = JSON.parse(data);
      }
      cartData.push(product);
      this.updateCartData(cartData);
      localStorage.setItem('cart', JSON.stringify(cartData));
      alert("Your item is added to cart");
  }
  getProducts(): void{
      console.log("getProducts Called...");
      this.productService.getProducts().subscribe(product => this.products = product);
  }

  save():void{
    //this.cart.addToCart(this.selectedProduct);
      
      //this.selectedProduct[productId].isAdded = true;
  }
  updateCartData(cartData) {
    this.cartProducts = cartData;
  }

}
